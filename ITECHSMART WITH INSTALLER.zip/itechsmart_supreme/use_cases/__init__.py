"""
Use Case Implementations
Pre-built remediation scenarios matching the website demos
"""