# iTechSmart Supreme - Deployment Guide

## 📋 Table of Contents

1. [Prerequisites](#prerequisites)
2. [Quick Start Deployment](#quick-start-deployment)
3. [Production Deployment](#production-deployment)
4. [Configuration](#configuration)
5. [Monitoring Setup](#monitoring-setup)
6. [Security Hardening](#security-hardening)
7. [Troubleshooting](#troubleshooting)

## Prerequisites

### System Requirements

- **Operating System**: Linux (Ubuntu 20.04+, CentOS 8+, Debian 11+)
- **CPU**: 2+ cores recommended
- **RAM**: 4GB minimum, 8GB recommended
- **Disk**: 20GB minimum
- **Network**: Outbound access to monitored systems

### Software Requirements

- Docker 20.10+ and Docker Compose 2.0+
- OR Python 3.11+ for manual installation
- Access to monitoring systems (Prometheus, Wazuh, etc.)

## Quick Start Deployment

### Option 1: Docker Compose (Recommended)

```bash
# 1. Clone the repository
git clone https://github.com/yourusername/itechsmart-supreme.git
cd itechsmart-supreme

# 2. Create environment file
cp .env.example .env

# 3. Edit configuration
nano .env

# 4. Start the application
docker-compose up -d

# 5. Check logs
docker-compose logs -f itechsmart-supreme

# 6. Access dashboard
open http://localhost:5000
```

### Option 2: Manual Installation

```bash
# 1. Install Python dependencies
pip install -r requirements.txt

# 2. Set environment variables
export OFFLINE_MODE=true
export AUTO_REMEDIATION=false
export MASTER_PASSWORD=your-secure-password

# 3. Run the application
python main.py
```

## Production Deployment

### 1. Infrastructure Setup

#### Using Docker Swarm

```bash
# Initialize swarm
docker swarm init

# Deploy stack
docker stack deploy -c docker-compose.yml itechsmart

# Check services
docker service ls
```

#### Using Kubernetes

Create `k8s-deployment.yaml`:

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: itechsmart-supreme
spec:
  replicas: 2
  selector:
    matchLabels:
      app: itechsmart-supreme
  template:
    metadata:
      labels:
        app: itechsmart-supreme
    spec:
      containers:
      - name: itechsmart-supreme
        image: itechsmart/supreme:latest
        ports:
        - containerPort: 5000
        env:
        - name: OFFLINE_MODE
          value: "true"
        - name: AUTO_REMEDIATION
          value: "false"
        volumeMounts:
        - name: data
          mountPath: /app/data
      volumes:
      - name: data
        persistentVolumeClaim:
          claimName: itechsmart-data
---
apiVersion: v1
kind: Service
metadata:
  name: itechsmart-supreme
spec:
  type: LoadBalancer
  ports:
  - port: 80
    targetPort: 5000
  selector:
    app: itechsmart-supreme
```

Deploy:

```bash
kubectl apply -f k8s-deployment.yaml
```

### 2. Reverse Proxy Setup (Nginx)

Create `/etc/nginx/sites-available/itechsmart-supreme`:

```nginx
server {
    listen 80;
    server_name itechsmart.yourdomain.com;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

Enable and restart:

```bash
sudo ln -s /etc/nginx/sites-available/itechsmart-supreme /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### 3. SSL/TLS Setup (Let's Encrypt)

```bash
# Install certbot
sudo apt-get install certbot python3-certbot-nginx

# Obtain certificate
sudo certbot --nginx -d itechsmart.yourdomain.com

# Auto-renewal
sudo certbot renew --dry-run
```

## Configuration

### Environment Variables

```bash
# Core Settings
MASTER_PASSWORD=your-very-secure-master-password
SECRET_KEY=your-flask-secret-key-min-32-chars

# AI Settings
OFFLINE_MODE=true  # Use false for OpenAI GPT-4
OPENAI_API_KEY=sk-your-api-key

# Automation
AUTO_REMEDIATION=false  # Start with false, enable after testing
REQUIRE_APPROVAL_HIGH_RISK=true

# Monitoring Endpoints
PROMETHEUS_ENDPOINTS=http://prometheus-server:9090
WAZUH_ENDPOINTS=https://wazuh-server:55000:admin:SecurePassword123

# Webhook Secrets
GITHUB_WEBHOOK_SECRET=your-github-webhook-secret
PROMETHEUS_WEBHOOK_SECRET=your-prometheus-webhook-secret

# Server
HOST=0.0.0.0
PORT=5000
```

### Adding Monitored Hosts

#### Via API

```bash
# Linux host with password
curl -X POST http://localhost:5000/api/hosts \
  -H "Content-Type: application/json" \
  -d '{
    "host": "server1.example.com",
    "username": "admin",
    "password": "secure-password",
    "platform": "linux",
    "port": 22,
    "use_sudo": true
  }'

# Linux host with SSH key
curl -X POST http://localhost:5000/api/hosts \
  -H "Content-Type: application/json" \
  -d '{
    "host": "server2.example.com",
    "username": "admin",
    "private_key": "/path/to/key.pem",
    "platform": "linux",
    "port": 22,
    "use_sudo": true
  }'

# Windows host
curl -X POST http://localhost:5000/api/hosts \
  -H "Content-Type: application/json" \
  -d '{
    "host": "windows-server.example.com",
    "username": "Administrator",
    "password": "SecurePassword123",
    "platform": "windows",
    "port": 5985,
    "domain": "DOMAIN"
  }'
```

## Monitoring Setup

### Prometheus Integration

1. **Configure Prometheus to scrape your infrastructure**

Create `prometheus.yml`:

```yaml
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: 'node-exporter'
    static_configs:
      - targets:
        - 'server1:9100'
        - 'server2:9100'
        - 'server3:9100'

  - job_name: 'application'
    static_configs:
      - targets:
        - 'app-server:8080'
```

2. **Configure Alertmanager**

Create `alertmanager.yml`:

```yaml
global:
  resolve_timeout: 5m

route:
  group_by: ['alertname', 'cluster']
  group_wait: 10s
  group_interval: 10s
  repeat_interval: 12h
  receiver: 'itechsmart-supreme'

receivers:
  - name: 'itechsmart-supreme'
    webhook_configs:
      - url: 'http://itechsmart-supreme:5000/webhook/prometheus'
        send_resolved: true
```

### Wazuh Integration

1. **Configure Wazuh Integration**

Edit `/var/ossec/etc/ossec.conf`:

```xml
<integration>
  <name>custom-webhook</name>
  <hook_url>http://itechsmart-supreme:5000/webhook/wazuh</hook_url>
  <level>7</level>
  <alert_format>json</alert_format>
</integration>
```

2. **Restart Wazuh**

```bash
systemctl restart wazuh-manager
```

### GitHub Webhooks

1. Go to your repository settings
2. Navigate to Webhooks
3. Add webhook:
   - **Payload URL**: `http://your-server:5000/webhook/github`
   - **Content type**: `application/json`
   - **Secret**: Your webhook secret
   - **Events**: Select "Issues", "Workflow runs", "Push"

## Security Hardening

### 1. Firewall Configuration

```bash
# Allow only necessary ports
sudo ufw allow 22/tcp    # SSH
sudo ufw allow 80/tcp    # HTTP
sudo ufw allow 443/tcp   # HTTPS
sudo ufw enable
```

### 2. Credential Security

```bash
# Generate strong master password
openssl rand -base64 32

# Set restrictive permissions on credential file
chmod 600 /app/data/credentials.enc
```

### 3. Network Isolation

- Deploy iTechSmart Supreme in a management VLAN
- Use VPN for remote access
- Implement network segmentation

### 4. Authentication (Add Your Own)

iTechSmart Supreme doesn't include authentication by default. Implement using:

- **OAuth2/OIDC**: Integrate with your identity provider
- **Basic Auth**: Add via Nginx
- **API Keys**: Implement in Flask middleware

Example Nginx basic auth:

```bash
# Create password file
sudo htpasswd -c /etc/nginx/.htpasswd admin

# Update Nginx config
location / {
    auth_basic "Restricted Access";
    auth_basic_user_file /etc/nginx/.htpasswd;
    proxy_pass http://localhost:5000;
}
```

### 5. Regular Updates

```bash
# Update Docker images
docker-compose pull
docker-compose up -d

# Update Python packages
pip install --upgrade -r requirements.txt
```

## Troubleshooting

### Common Issues

#### 1. Connection Refused

**Problem**: Cannot connect to monitored hosts

**Solution**:
```bash
# Check network connectivity
ping server1.example.com

# Test SSH connection
ssh admin@server1.example.com

# Check firewall rules
sudo iptables -L
```

#### 2. Webhook Not Receiving Events

**Problem**: Webhooks not triggering alerts

**Solution**:
```bash
# Check webhook endpoint
curl http://localhost:5000/webhook/health

# Verify webhook secret
# Check logs for signature verification errors
docker-compose logs -f itechsmart-supreme
```

#### 3. High Memory Usage

**Problem**: Application consuming too much memory

**Solution**:
```bash
# Limit Docker memory
docker-compose down
# Edit docker-compose.yml
services:
  itechsmart-supreme:
    mem_limit: 2g
docker-compose up -d
```

#### 4. Credentials Not Working

**Problem**: Cannot authenticate to hosts

**Solution**:
```bash
# Verify credentials
curl http://localhost:5000/api/hosts

# Test manually
ssh -i /path/to/key.pem admin@server1.example.com

# Check credential file permissions
ls -la /app/data/credentials.enc
```

### Logs and Debugging

```bash
# View application logs
docker-compose logs -f itechsmart-supreme

# View specific component logs
docker-compose logs -f itechsmart-supreme | grep "AI Diagnosis"

# Enable debug mode (not for production)
export FLASK_DEBUG=1
python main.py
```

### Health Checks

```bash
# API health check
curl http://localhost:5000/api/health

# System status
curl http://localhost:5000/api/status

# Check kill switch status
curl http://localhost:5000/api/killswitch/status
```

## Backup and Recovery

### Backup

```bash
# Backup credentials
cp /app/data/credentials.enc /backup/credentials.enc.$(date +%Y%m%d)

# Backup logs
tar -czf /backup/logs-$(date +%Y%m%d).tar.gz /app/logs/

# Backup configuration
cp .env /backup/.env.$(date +%Y%m%d)
```

### Recovery

```bash
# Restore credentials
cp /backup/credentials.enc.20240101 /app/data/credentials.enc

# Restart application
docker-compose restart itechsmart-supreme
```

## Monitoring iTechSmart Supreme

### Prometheus Metrics

iTechSmart Supreme exposes metrics at `/metrics`:

```bash
curl http://localhost:5000/metrics
```

### Health Monitoring

Set up external monitoring:

```bash
# Add to your monitoring system
*/5 * * * * curl -f http://localhost:5000/api/health || alert
```

## Scaling

### Horizontal Scaling

For high availability:

```bash
# Docker Swarm
docker service scale itechsmart_supreme=3

# Kubernetes
kubectl scale deployment itechsmart-supreme --replicas=3
```

### Load Balancing

Use Nginx or HAProxy for load balancing:

```nginx
upstream itechsmart {
    server 10.0.0.1:5000;
    server 10.0.0.2:5000;
    server 10.0.0.3:5000;
}

server {
    listen 80;
    location / {
        proxy_pass http://itechsmart;
    }
}
```

## Support

For issues and questions:

- GitHub Issues: https://github.com/yourusername/itechsmart-supreme/issues
- Documentation: https://docs.itechsmart.com
- Email: support@itechsmart.com

---

**Deployment Checklist**

- [ ] Environment variables configured
- [ ] Credentials encrypted and secured
- [ ] Monitoring endpoints configured
- [ ] Webhooks set up and tested
- [ ] SSL/TLS certificates installed
- [ ] Firewall rules configured
- [ ] Backup strategy implemented
- [ ] Health checks configured
- [ ] Documentation reviewed
- [ ] Team trained on usage

**Ready to deploy? Let's eliminate downtime forever! 🚀**